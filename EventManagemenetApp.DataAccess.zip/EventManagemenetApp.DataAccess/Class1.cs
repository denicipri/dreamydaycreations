﻿namespace EventManagemenetApp.DataAccess
{
    public class Class1
    {

    }
}